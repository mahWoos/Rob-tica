document.addEventListener('DOMContentLoaded', () => {
    console.log('Site carregado e pronto!');
    // Adicione scripts interativos aqui
});
